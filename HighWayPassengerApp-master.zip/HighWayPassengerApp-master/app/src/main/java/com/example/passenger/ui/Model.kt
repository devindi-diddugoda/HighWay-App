package com.example.passenger.ui

data class Bus(
    val id: Int,
    val time: String,
    val ratings: Float,
    val description: String,
    val route: String,
    val type: String
)